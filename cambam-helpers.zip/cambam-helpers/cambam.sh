cd ~/CamBam0.9.8/
mono ./CamBam.exe "$1"
